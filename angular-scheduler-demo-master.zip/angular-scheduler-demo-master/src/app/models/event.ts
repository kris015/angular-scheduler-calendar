export class Event {
    id: string;
    start_date: string;
    end_date: string;
    text: string;
}